import { useEffect } from 'react';

interface PageMeta {
  /** Document title for this page */
  title?: string;
  /** Meta description (also used for og:description) */
  description?: string;
  /** Optional Open Graph image URL */
  image?: string;
}

function upsertMeta(attr: 'name' | 'property', key: string, content: string): void {
  const selector = `meta[${attr}="${key}"]`;
  let el = document.head.querySelector<HTMLMetaElement>(selector);
  if (!el) {
    el = document.createElement('meta');
    el.setAttribute(attr, key);
    document.head.appendChild(el);
  }
  el.setAttribute('content', content);
}

/**
 * Sets the document title and SEO/social meta tags for the current page.
 *
 * Usage:
 * ```tsx
 * usePageMeta({ title: 'Products', description: 'Browse our catalog' });
 * ```
 */
export function usePageMeta({ title, description, image }: PageMeta): void {
  useEffect(() => {
    if (title) {
      document.title = title;
      upsertMeta('property', 'og:title', title);
    }
    if (description) {
      upsertMeta('name', 'description', description);
      upsertMeta('property', 'og:description', description);
    }
    if (image) {
      upsertMeta('property', 'og:image', image);
    }
    upsertMeta('property', 'og:type', 'website');
  }, [title, description, image]);
}
