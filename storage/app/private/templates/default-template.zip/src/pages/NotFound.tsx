import { usePageMeta } from '../hooks/usePageMeta';
import { Link } from 'react-router-dom'
import { Button } from '../components/ui/button'

export default function NotFound() {
  usePageMeta({ title: 'Page not found' })
  return (
    <div className="min-h-[60vh] flex items-center justify-center">
      <div className="text-center px-4">
        <h1 className="text-6xl font-bold text-foreground mb-4">404</h1>
        <p className="text-xl text-muted-foreground mb-8">
          Oops! The page you're looking for doesn't exist.
        </p>
        <Link to="/">
          <Button size="lg">Go Home</Button>
        </Link>
      </div>
    </div>
  )
}
