/// <reference types="vite/client" />

// Unified __APP_CONFIG__ type declaration (used by supabase.ts and useSystemStorage.ts)
interface SupabaseClientConfig {
  url: string
  publishableKey: string
  schema: string
}

interface SystemConfig {
  apiUrl: string
  projectId: string
  apiToken: string
  supabase?: SupabaseClientConfig
}

declare global {
  interface Window {
    __APP_CONFIG__?: SystemConfig
  }
}

export {}
