# Default Template — Knowledge

A generic single-page starter. `src/pages/Home.tsx` is the primary canvas and
the only meaningful page (plus `NotFound.tsx`).

## Pages
- **`Home.tsx`** — the canvas. For marketing sites it holds stacked sections
  (hero, features, etc.); for a tool/app it IS the app.
- **`NotFound.tsx`** — 404, already wired via the `*` route.

## How to build into it
- **"Make/build a <tool/app>"** (calculator, task manager, generator, timer,
  todo) → REPLACE the contents of `Home.tsx` with the app. Do NOT create a
  separate page — the Home route IS the app.
- **"Add a section"** → insert a new `<section>` into `Home.tsx`.
- **"Add a <name> page"** → create `src/pages/<Name>.tsx` and register it in
  `routes.tsx`.

## Conventions
- Single-purpose apps: keep all state in `Home.tsx` or small `src/hooks/`
  helpers; persist with `useData` (Supabase) when the user wants saved data.
- This template has the widest shadcn component set — prefer composing
  existing `ui/` primitives over hand-rolling.

---

# Shared architecture (common to every template)

## Stack
React 18 + TypeScript + Vite 6 + Tailwind CSS v4 + shadcn/ui. Every source file
is `.tsx`/`.ts`. `template.json` at the project root is the authoritative map of
file structure, pages, components, and styling — trust it over assumptions.

## Routing & layout
- **`src/routes.tsx`** exports `routes: RouteConfig[]`. Each entry:
  `{ path, label, element, showInNav, layout }` where `layout` is
  `'default'` (nav + footer) or `'bare'` (standalone — auth, checkout, single
  landing). Add a page by importing it and pushing a `RouteConfig`.
- **`src/main.tsx`** already wraps the app in `<BrowserRouter>` — NEVER add
  another `<BrowserRouter>`; a nested one renders a blank page with no error.
  `main.tsx` also calls `initSupabase()` before render and sets the router
  basename — do not modify this file.
- **`src/App.tsx`** applies the `Layout` centrally based on each route's
  `layout`. Pages must NOT import `Layout`, `Navigation`, or render their own
  header/footer — they render section content only.

## Supabase data hooks (`src/hooks/`, import from `@/hooks`)
Supabase initializes in `main.tsx` before React renders — never re-initialize
it in a component. All collections are auto-prefixed per project.

**`useData<T>(collectionName, sampleData, options?)`** — the primary hook for
list/collection data. Auto-switches: live Supabase when Supabase is
configured, `sampleData` while the first snapshot loads, then the real
collection (including an empty one). Returns:
`{ data, loading, error, isLive, add, update, remove, refresh }`.
```tsx
const { data: products, loading } = useData<Product>('products', SAMPLE_PRODUCTS);
if (loading) return <LoadingState />;
```

**`useAuth()`** — email/password auth. Returns:
`{ user, loading, error, isAuthenticated, signUp, signIn, signOut,
resetPassword, clearError }`. `user` is `AuthUser | null`.

**`useSupabase<T>(collectionName, options?)`** — raw realtime collection
access. Returns `{ documents, loading, error, add, update, remove, refresh }`.
`options` is `{ constraints?: QueryConstraint[], enabled?: boolean }`.
⚠️ `constraints` MUST be a stable reference — define it at module scope or wrap
it in `useMemo`. A fresh array literal each render re-subscribes every render.

**`useSystemStorage()`** — file uploads. Returns
`{ upload, deleteFile, getFiles, uploading, error, isConfigured }`.

**`useTheme()` / `ThemeProvider`** — light/dark/system theme.
**`usePageMeta({ title, description, image? })`** — call once at the top of
every page to set the document `<title>` + SEO/OpenGraph meta tags.

When Supabase is not configured, `useData` returns `sampleData` and its
write functions are no-ops (they `console.warn`). Always ship realistic
`sampleData` so the page looks complete without a backend.

## Components & libraries
- **Custom components** (`@/components/`): `Layout`, `Navigation`,
  `ErrorBoundary`, `ProtectedRoute` (wraps auth-required pages — shows a clear
  panel when Supabase is absent), `ThemeToggle`, `EmptyState`, `LoadingState`.
- **shadcn/ui** (`@/components/ui/`): accordion, alert, alert-dialog, avatar, badge, button,
  card, checkbox, dialog, dropdown-menu, input, label, progress, select,
  separator, sheet, skeleton, sonner (toast), switch, table, tabs, textarea,
  tooltip. Use `listComponents`/`getComponentUsage` for exact APIs.
- **`@/lib/utils`** — `cn(...)` to merge Tailwind classes.
- **`@/lib/format`** — `formatPrice`, `formatDate`, `formatNumber`,
  `formatRelativeTime`, `truncate`, `slugify`.
- **`@/lib/validation`** — zod schemas: `emailSchema`, `passwordSchema`,
  `loginSchema`, `signupSchema`, `contactSchema`, `newsletterSchema`.
- Icons: `lucide-react`. Use `listIcons`/`getIconUsage` to verify names.

## Theme & styling
This template ships a **neutral baseline only**. The project's visual identity —
colors, typography, radius, and elevation — is provided by an installed
**design system**, applied automatically at build time.

- Build with the **semantic tokens**, never hardcoded values: surfaces use
  `bg-background` / `bg-card` / `bg-muted`, text uses `text-foreground` /
  `text-muted-foreground`, actions use `bg-primary` + `text-primary-foreground`,
  borders use `border-border`. Typography uses `font-sans` / `font-serif`.
- Never hardcode brand colors (e.g. `bg-indigo-600`) or font families — that
  bypasses the design system and will look wrong once a system is applied.
- Functional status colors (e.g. green for success/in-stock, red for errors)
  are acceptable where they convey meaning, not brand.
## Critical rules
- First tool calls: `readFile("template.json")`, then the file most relevant to
  the request.
- Never nest `<BrowserRouter>`. Never edit `index.css` or `main.tsx`.
- Every `<a>`/`<Link>` needs a real route or `#anchor` — never `href="#"`.
- A new page is only reachable after it is registered in `src/routes.tsx`.
- Run `verifyBuild`, then `verifyIntegration`, before reporting completion.
