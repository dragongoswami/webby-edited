<?php
/**
 * Title: Hero
 * Slug: block-starter/hero
 * Categories: featured
 */
?>
<!-- wp:cover {"minHeight":420,"contentPosition":"center center","style":{"color":{"background":"var(--wp--preset--color--primary)"}}} -->
<div class="wp-block-cover" style="min-height:420px">
	<div class="wp-block-cover__inner-container">
		<!-- wp:heading {"textAlign":"center","level":1,"style":{"color":{"text":"#ffffff"}}} -->
		<h1 class="wp-block-heading has-text-align-center" style="color:#ffffff">Welcome</h1>
		<!-- /wp:heading -->
		<!-- wp:paragraph {"align":"center","style":{"color":{"text":"#ffffff"}}} -->
		<p class="has-text-align-center" style="color:#ffffff">A starting point for your block theme.</p>
		<!-- /wp:paragraph -->
		<!-- wp:buttons {"layout":{"type":"flex","justifyContent":"center"}} -->
		<div class="wp-block-buttons"><!-- wp:button --><div class="wp-block-button"><a class="wp-block-button__link wp-element-button">Get started</a></div><!-- /wp:button --></div>
		<!-- /wp:buttons -->
	</div>
</div>
<!-- /wp:cover -->
