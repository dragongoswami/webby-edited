# Substrate — design system playbook (authoritative)

You are building on **Substrate**: a warm-neutral base, the **Geist** typeface
(Newsreader for editorial), a 10px radius, and a tactile, warm-tinted shadow
scale. The accent for this project is already set. **Build ON the system — never
flatten it back to generic.**

- **`src/index.css` is PROTECTED — never edit it.** Put any overrides in
  **`src/custom.css`** (cascades after `index.css`). If you override a CSS var,
  set it in BOTH `:root` and `.dark` or dark mode breaks. HSL is `H S% L%`.
- **Semantic tokens only — never raw colors.** `bg-primary text-primary-foreground`,
  `bg-card`, `bg-muted`, `text-muted-foreground`, `border-border`. Never `bg-blue-500`.
  The accent + dark mode then just work. Lead with `primary` for CTAs/active states;
  keep most surfaces neutral.
- **Type scale:** Display `text-5xl`/`text-6xl` · H1 `text-4xl` · H2 `text-3xl` ·
  H3 `text-2xl` · body `text-base leading-relaxed` · small `text-sm` · eyebrow
  `text-xs uppercase tracking-wide text-muted-foreground`. Headings are already
  weighted + tracked in the base — don't fight it. `font-serif` for editorial long-form.
- **Elevation:** cards/inputs `shadow-sm`, raised/hover `shadow-md`, popovers
  `shadow-lg`, dialogs `shadow-xl`. Prefer a soft shadow + `border` over heavy borders;
  add `transition-shadow hover:shadow-md` for tactile cards.
- **Spacing rhythm:** generous sections (`py-16 md:py-24`), content in a centered
  `max-w-6xl mx-auto px-4`, `gap-6`/`gap-8` between cards. Whitespace IS the look.
- **Polish:** `rounded-lg`/`rounded-xl`, `focus-visible` rings come from `--ring`,
  prefer `gap-*` over margins. Restrained and premium (Linear / Vercel / Stripe grade)
  — not loud.
